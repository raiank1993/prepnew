package com.thinkandcode.prepnew.interview;

public enum TaskStatus {
    NEW, INPROGRESS, COMPLETED
}
