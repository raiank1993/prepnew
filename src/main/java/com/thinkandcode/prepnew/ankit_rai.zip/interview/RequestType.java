package com.thinkandcode.prepnew.interview;

public enum RequestType {
    Add, REMOVE, MODIFY
}
